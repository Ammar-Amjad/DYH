Roadmap
=======

This part of the documentation keeps track of desired features in future releases.

- Update usage with an example using the DeepCASE class.

Nice to haves
^^^^^^^^^^^^^
Features that are listed here would be nice to have for DeepCASE.
I probably won't implement them myself, but feel free to send me a pull request.

- None at the moment

Changelog
^^^^^^^^^
Version 1.0.1:
 * Added DeepCASE class

Version 0.0.2:
 * Added fit/predict functionality to ContextBuilder and Interpreter.

Version 0.0.1:
 * Initial release
