Contributors
============

This page lists all the contributors to this project.
If you want to be involved in maintaining code or adding new features, please email t(dot)s(dot)vanede(at)utwente(dot)nl.

Code
^^^^
 - Thijs van Ede
 
Special Thanks
^^^^^^^^^^^^^^
**We want to give our special thanks for people reporting bugs and fixes.**
 - Ammar-Amjad

Academic Contributors
^^^^^^^^^^^^^^^^^^^^^
 - Thijs van Ede
 - Hojjat Aghakhani
 - Noah Spahn
 - Riccardo Bortolameotti
 - Marco Cova
 - Andrea Continella
 - Maarten van Steen
 - Andreas Peter
 - Christopher Kruegel
 - Giovanni Vigna

